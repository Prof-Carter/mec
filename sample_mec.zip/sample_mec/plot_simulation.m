clear
format compact

% ���f���}�b�`���O
% �uMATLAB/Simulink �ɂ�鐧��H�w����v�� pp.128-129 ���Q��
d0 = 2;
d1 = 3;
d2 = 1;
% --------------------
wm = 2;
a1 = 1.4;
gamma_m1 = a1/wm;
gamma_m2 =  1/wm^2;
gamma_m3 =  0;
% --------------------
kI2 =  d0/gamma_m1
kP2 = (d2*gamma_m1 - d0*gamma_m3)/(gamma_m1*gamma_m2)
kD2 = (d2*gamma_m1^2 - d1*gamma_m1*gamma_m2 ...
                  + d0*(gamma_m2^2 - gamma_m1*gamma_m3))/(gamma_m1*gamma_m2)

% �ϓ��p�����[�^
T_data = 0.5:0.5:1.5;
K_data = 0.5:0.5:1.5;

% �덷�⏞��FPI
kP1 = 80;
kI1 = 40;

% % �덷�⏞��FP
% kP1 = 80;
% kI1 = 0;

rc = 1;  % �ڕW�l
dc = 2;  % �O��

% --------------------
s = tf('s');
sysGm2 = wm^2/(s^2 + a1*wm*s + wm^2);
tsim = 0:0.001:10;
yM = step(sysGm2,tsim);

% --------------------
for k = 11:13
    figure(k)
    set(gcf,'Color','white','PaperType','A3')
    set(gcf,'Position',[100 100 800 400]) % [x0 y0 width height]
    subplot('Position',[0.2 0.2 0.7 0.7]) % [left bottom width height]
end

for k = 21:23
    figure(k)
    set(gcf,'Color','white','PaperType','A3')
    set(gcf,'Position',[100 100 800 400]) % [x0 y0 width height]
    subplot('Position',[0.2 0.2 0.7 0.7]) % [left bottom width height]
end

for i = 1:length(T_data)
    for j = 1:length(K_data)

        T = T_data(i);
        K = K_data(j);

        sim('simulation_R2023a')
%        sim('simulation_R2018a')

        figure(11)
        movegui('northwest')
        plot(t,y,'LineWidth',1)
        hold on

        figure(12)
        movegui('north')
        plot(t,y2,'LineWidth',1)
        hold on

        figure(13)
        movegui('northeast')
        plot(t,y_normal,'LineWidth',1)
        hold on

        figure(21)
        movegui('southwest')
        plot(t,u_tilde,'LineWidth',1)
        hold on

        figure(22)
        movegui('south')
        plot(t,u_tilde2,'LineWidth',1)
        hold on

        figure(23)
        movegui('southeast')
        plot(t,u_normal,'LineWidth',1)
        hold on
    end
end

for k = 11:13
    figure(k)
    hold on
    p = plot(1+tsim,yM,'--','Color',0.2*[1 1 1],'LineWidth',1.5);

    legend(p,{'Reference model'},'Location','southeast')
    set(legend,'FontName','Arial','FontSize',14)
end

for k = 11:13
    figure(k)
    hold off
    axis([0 10 -0.05 1.4])
    set(gca,'XTick',0:1:10)
    set(gca,'FontName','Arial','FontSize',14)
    xlabel('Time [s]','FontName','Arial','FontSize',16)
    ylabel('y(t)','FontName','Arial','FontSize',16)
    grid on
end

for k = 21:23
    figure(k)
    hold off
    axis([0 10 -5 15])
    set(gca,'XTick',0:1:10)
    set(gca,'FontName','Arial','FontSize',14)
    xlabel('Time [s]','FontName','Arial','FontSize',16)
    ylabel('u(t)','FontName','Arial','FontSize',16)
    grid on
end

